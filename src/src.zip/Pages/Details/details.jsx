 
 
// import Body from "../../Components/Body";
// import Header from "../../Components/Header";
import Header from "../../Component/Header/header";
import Content from "../../Component/Content/content";
import Similar  from "../../Component/Similar/smilar";
function Detail(){
        return(
            <div>
                <Header />
               <Content />
              <Similar />
            </div>
        )
}
export default Detail;