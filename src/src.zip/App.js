import logo from './logo.svg';
import "bootstrap/dist/css/bootstrap.min.css";
import './App.css'; 
import Detail from './Pages/Details/details'; 
function App() {
  return (
    <div className="App">
      <Detail />
    </div>
  );
} 
 
export default App;
